
    import java.util.Scanner;

    public class Atividade1{
        public static void main(String[] args) {
            //CRIAR UM PROGRAMA QUE PERMITA CADASTRAR AS AVALIAÇÕES DE UMA LISTA DE CARROS
            //1- SOLICITAR A QUANTIDADE DE CARROS
            //2- ARMAZENAR UM VETOR AS AVALIAÇÕES DE CADA CARRO (NOTAS DE 0 A 10)

            Scanner sc = new Scanner(System.in);
            int quantCarro = 0;
            double nota = 0;



            System.out.println("Informe a quantidade de carros: ");
            double[] notas = new


            for (int i = 0; i < quantCarro; i++) {

                System.out.println("Informe a nota : ");
                nota = sc.nextInt();

                if(nota >=6){
                    System.out.println("Esse carro é bom");
                }else if(nota <6){
                    System.out.println("Corre que esse é ruim");
                }
                else {
                    System.out.println("erro");
                }


            }



        }
    }




