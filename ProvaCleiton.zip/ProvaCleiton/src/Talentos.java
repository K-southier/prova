import java.util.Scanner;

public class Talentos {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int[] votosTaffe [];
        int votantes =0;
        int numero = 0;

        System.out.println("quantidade de votantes: ");
        votantes = sc.nextInt();

        System.out.println("SEGUE A LISTA PARA A VOTAÇÃO: 80 - Taffe, 70 -RODRIGO, 60 - LUCAS, 50 - ALESSANDRO");
        numero = sc.nextInt();


        if(numero == 80){
            System.out.println("Taffe");

        }
        if(numero == 70){
            System.out.println("Rodrigo");
        }
        if(numero == 60){
            System.out.println("Lucas");
        }
        if(numero == 50){
            System.out.println("Alessandro");
        }

    }

}
